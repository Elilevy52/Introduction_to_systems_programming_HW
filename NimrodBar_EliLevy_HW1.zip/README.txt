מבוא לתכנות מערכות - מטלה מס' 1.
מגישים:
נמרוד בר - 203531801
אלי לוי - 206946790
https://github.com/Elilevy52/Introduction_to_systems_programming_HW.git
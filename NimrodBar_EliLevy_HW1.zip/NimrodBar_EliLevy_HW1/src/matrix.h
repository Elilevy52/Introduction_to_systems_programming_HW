#pragma once
void fillRandomMat(char* mat, int rows, int cols);
void printMat(const char* mat, int rows, int cols);
void Count(const char* bigMat, const char* smallMat, int* resMat, int bigSize, int smallSize, int resSize, char* LetterAppears, int* maxCounter);
void printResMat(const int* mat, int rows, int cols);
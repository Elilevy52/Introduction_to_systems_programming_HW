#pragma once
char* MakeString(char *mat, int rows, int cols, char *pStr);
void swap(char *s1, char *s2);
char* RevWords(char *str, int size);
